var stellingen = [
    "Nederland moet terug naar de Gulden",
    "Er moet meer geld naar ontwikkelingshulp",
    "De overheid moet afslanken",
    "De AOW leeftijd moet terug naar 67 jaar",
    "Wietteelt moet worden gelegaliseerd",
    "We moeten minder geld aan het leger uitgeven",
    "Alle werkenden moeten minder loonbelasting betalen",
    "Snelwegen moeten hogere snelheden zijn",
    "Wegenbelasting moet omlaag",
    "BTW moet terug naar 12%"
]