var titel = document.getElementById("title");
var description = document.getElementById("description");
var button1 = document.getElementById("button1");
var button2 = document.getElementById("button2");
var button3 = document.getElementById("button3");
var inventory = document.getElementById("inventoryItem");
var map = document.getElementById("maps");
var game = document.getElementById("game-container");

function allButtons(qty) {
    for (i = 1; i <= qty; i++) {
        document.getElementById("button"+i).setAttribute("class","buttons");
    }
}

function gameContainer() {
    game.style.display = "block";
    game.style.width = "50%";
    game.style.height = "300px";
    game.style.margin = "0 auto";
    game.style.backgroundColor = "black";
    game.style.border = "4px solid maroon";
    game.style.color = "white";
    game.style.textAlign = "center";
    game.style.opacity = "0.7";
}

function Button() {
    button2.style.padding = "14px 40px";
    button2.style.borderRadius = "8px";
    button2.style.borderColor = "black";
    button2.style.backgroundColor = "black";
    button2.style.boxShadow = "5px 5px 5px black";
    button2.style.color = "white";
}

function StartGame() {
    document.body.style.background = "url(assets/img/start/background.jpg)";
    document.body.style.backgroundSize = "cover";

    button1.style.display = "none";
    button3.style.display = "none";

    Button();
    button2.style.marginTop = "580px";
    button2.style.marginLeft = "690px";
    button2.innerText = "Play";
    button2.setAttribute("onclick","StartMap()");

    map.style.display = "none";
    inventory.style.display = "none";
}

StartGame();

function StartMap() {
    gameContainer();
    allButtons(2);
    var naam = prompt("What username would you like to have?");

    document.body.style.background = "url(assets/img/maps/START.jpg)";
    document.body.style.backgroundSize = "cover";
    button1.style.display = "inline-block";
    button3.style.display = "inline-block";
    
    titel.innerText = "Back home";
    description.innerText = "Goodevening Mr." + naam + ",\n You are on your way home. Your mother is waiting for you. She made diner for you. You'll arrive in 1 minute.";
    button2.setAttribute("onclick","StartMap()");
}






















































































































































































